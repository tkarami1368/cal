
from distutils.core import setup
import py2exe
# Import the tkinter module


setup(console=['tkarami.py'])